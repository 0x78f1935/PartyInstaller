## WetDreams: Complete Story | v0.11.3 csc 0.9.0
##### Thank YOU for YOUR time! Enjoy!
*Download is underneath the big image*

# Welcome!
> First of all, Thank you all who tried my first custom story: `Biscuits and Tea with Amy the Sweetie`
> Obviously this was all together a joke and not ment to be serious. The story was more so I could
> fiddle around with the story creator. I really appriciate that I recieved DM's with translation requests,
> however... `Biscuits and Tea with Amy the Sweetie` is finished and done for what it is. I don't want to
> create free time for `Biscuits and Tea with Amy the Sweetie`. Don't be sad though.. `WetDreams` will recieve
> updates in the future. I tons of possibilities and extension idea's so this could be a fun adventure! Anyways..
> I hope you enjoy!

# Installation
Copy the folder "WetDreams" to the following location:
`C:\Users\[your account name]\Documents\Eek\House Party\Mods\Stories`

# My thoughts
> I had a lot of fun creating this story and I think this story is a pretty good base to expand on in the future.
> Please inform me what your thoughts are about the lenght of this story which you can do HERE: https://www.strawpoll.me/16235727
> Ofcourse keep in mind that `I'm aware that this is a early acces game` with the follwing things that I have to say
> about my story create adventure.

# Known Issues

`Not everything listed here is a CSC nor game bug. Some things in my list are already solved or was my own mistake.`
`I would make clear which "bugs" (are not bugs but human mistakes) I'm talking about. Once again:`
`I created this list along the way while building this custom story, this part is spoiler free`

## `ON FADE OUT`
> When a fadeout happens and if you are rushing stuff (like in test cases)
> somehow the screen can stay black.. The Fade In wont trigger.. 
> If your screen stays black after it became black longer then 15 seconds you should consider restarting your custom story.
> And if you can beat my score, grats to you sir/madam! My speed run time was `05:09:42` **min**:**sec**:**mili-sec**

## `QUESTS`
> I think this story is on a decent size, When your quest list is becomming bigger in the time you play the story,
> There may be a visual bug that you could encounter. Quests that you already did are shown as in process... 
> You can easly fix this while you are in game. Make sure you check the `"Hide finished quests"` box.

## `SOUNDS`
> This is a big issue, or atleast a annoying one. Without spoiling to much.. 
> When you get fucked or get sucked and the job is done the sound keeps playing..... 
> For the rest of your playthrough. I dont know what the cause is and it can be enoying while playing.
> I'm really sorry for this audio bug. When I know a solution for this I fix it!

## `CABINET MENU`
> The cabinet menu can get stuck. It will be frozen on your screen and no options can be clicked.. 
> The following options are visable ["Inspect", "Open", "Unlock"]. Press your ESCAPE key and press it again. 
> The menu is gone and you can play along. This has no effect on the story. Try clicking the cabinet again!

---------------------------------------------
ADDTIONS
---------------------------------------------
- Maybe it is a idea to add the option to add color in the text?
- Maybe a feature that you can place object in another room? 
  `"place : broom : master bedroom closet : Game Start : or : place : broom : master bedroom closet : on_value : Vickie : Broom : 1"`
  Something like that?
- Toggle is usefull in some situations, not all situations. Would be nice to see a actual on/off for example with the toggle penis option.


`# If you don't want any spoiler I recommend to scroll down.`
`# Underneath the big picture will be the download link!`


##### Story
> Multiple endings is a thing again, but this your choice really makes a big impact this time.
> It's advisable to play this custom story more then 1 time. Without giving to much away,
> if you are homophobic please download another custom story. However.. if your reach 
> the hot tub there might be a naughty suprise waiting for you! Each story ending ends with
> a "GameOver" screen. Its pretty obvious reach the end!


DOWNLOAD