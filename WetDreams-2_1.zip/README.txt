To install this custom story place the complete folder in your "C:\Users\YOUR USER\Documents\Eek\House Party\Mods\Stories" folder.
You end up with the directory "C:\Users\YOUR USER\Documents\Eek\House Party\Mods\Stories\WetDreams-2"

When you start the game you should be able to find WetDreams 2 in your dropdown menu.